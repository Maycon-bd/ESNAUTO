# GUIA DE AVALIACAO DOS RESULTADOS DO TFC — PARA O ORIENTADOR
## Tema: Previsao de Series Temporais Financeiras (PETR4) via Echo State Networks com Distribuicoes Nao-Gaussianas e Algoritmo Genetico Hibrido (LHS + Cataclismo)
Autor: Maycon Garcia Silva  
Data: Agosto / 2026  
Repositorio Publico no GitHub: https://github.com/Maycon-bd/ESNAUTO

---

### Prezado(a) Professor(a) Orientador(a),

Este pacote contem os relatorios tecnicos, dados brutos consolidados das 30 rodadas experimentais das 4 Ondas Estocasticas e figuras em alta resolucao desenvolvidos no Trabalho de Fim de Curso (TFC).

O codigo-fonte completo do aplicativo web (ESNAUTO Benchmark Studio) e os scripts de reproducao estao disponiveis publicamente no GitHub:
👉 https://github.com/Maycon-bd/ESNAUTO

---

### ESTRUTURA DESTE PACOTE

├── 01_Relatorios_Tecnicos_e_Metodologia/
│   ├── Relatorio_Tecnico_4_Ondas_Estocasticas.md      # Relatorio completo das 30 rodadas oficiais
│   ├── Metodologia_GA_LHS_Cataclismo.md              # Formulacao do GA (59 bits, LHS e CHC)
│   ├── Monografia_TFC_MayconGarciaSilva.docx         # Versao editavel em Word da Monografia
│   └── Relatorio_Automacao_ESN.docx                 # Relatorio tecnico do pipeline
│
├── 02_Figuras_Alta_Resolucao/
│   ├── fig1_boxplot_mae_ondas.png / .pdf             # Boxplot de erro MAE no teste cego vs DL
│   ├── fig2_tempo_treinamento_speedup.png / .pdf     # Speedup >500x da ESN vs LSTM/GRU (escala log)
│   ├── fig3_campeoes_teste_serie.png / .pdf          # Serie temporal teste out-of-sample vs real
│   ├── fig4_dispersao_residuos.png / .pdf            # Dispersao Real x Previsto (R²=0.9940) e residuos
│   └── fig5_ranking_multicriterio.png / .pdf         # Ranking oficial ponderado multicriterio (Score 0-100)
│
└── 03_Planilhas_e_Dados_Brutos/
    ├── historico_30_rodadas_ga_4_ondas.csv           # Dados brutos das 30 rodadas oficiais (GA 10.000 geracoes)
    ├── historico_baselines_dl_lstm_gru.csv           # Metricas dos baselines de Deep Learning (LSTM e GRU)
    ├── PETR4_close_com_factor_2000-2020.txt          # Serie temporal bruta PETR4 (5.198 cotacoes)
    └── PETR4_serie_temporal_com_datas.csv            # Serie temporal indexada por datas

---

### SINTESE DOS PRINCIPAIS RESULTADOS EXPERIMENTAIS

1. Volume Computacional: Foram realizadas 30 rodadas oficiais de producao de Algoritmo Genetico em busca profunda de 10.000 geracoes, totalizando mais de 25 horas e 40 minutos de processamento local em dataset de 5.198 amostras (50% Treino, 25% Validacao, 25% Teste Cego).
2. Superioridade sobre Deep Learning Recorrente: Todas as 30 configuracoes de ESN superaram a LSTM (MAE = 0.4521, R² = 0.9839) e a GRU (MAE = 0.3566, R² = 0.9912) em erro no teste cego.
3. Recordes Oficiais Obtidos:
   * Campea Geral de Teste: ESN Onda 2 (Laplace + Normal) -> MAE Teste = 0.3272, R² = 0.9940 (Score: 98.8 / 100).
   * Campea de Aderencia: ESN Onda 2 (Laplace + Cauchy) -> Menor RMSE = 0.4953, Maior R² = 0.9941.
   * Eficiencia: Tempo de treino Ridge da ESN: 0.05 segundos (>500x mais rapida que as redes profundas).

---

### CODIGO-FONTE E REPRODUCAO NO GITHUB

Todo o codigo-fonte do aplicativo web Shiny (ESNAUTO Studio), os modulos de redes neurais e os scripts de reproducao automatizada estao versionados e acessiveis no repositorio:
https://github.com/Maycon-bd/ESNAUTO

Atenciosamente,  
Maycon Garcia Silva
